pipeline <- read.csv("raw-data/pipeline.csv")
save(pipeline, file = "data/pipeline.rda")
