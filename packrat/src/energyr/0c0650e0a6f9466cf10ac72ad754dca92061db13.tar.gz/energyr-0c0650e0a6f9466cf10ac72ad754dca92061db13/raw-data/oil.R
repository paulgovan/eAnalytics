oil <- read.csv("raw-data/oil.csv")
save(oil, file = "data/oil.rda")
