electric <- read.csv("raw-data/electric.csv")
save(electric, file = "data/electric.rda")
