gas <- read.csv("raw-data/gas.csv")
save(gas, file = "data/gas.rda")
