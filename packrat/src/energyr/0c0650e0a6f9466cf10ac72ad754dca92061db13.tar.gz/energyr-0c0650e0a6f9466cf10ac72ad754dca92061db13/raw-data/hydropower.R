hydropower <- read.csv("raw-data/hydropower.csv")
save(hydropower, file = "data/hydropower.rda")
