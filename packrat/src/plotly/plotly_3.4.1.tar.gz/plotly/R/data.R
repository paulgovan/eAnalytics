#' Wind data
#'
#' Description TBD.
#'
#' @format A data frame with three variables: \code{r}, \code{t},
#'   \code{nms}.
"wind"

#' Mic data
#'
#' Description TBD.
#'
#' @format A data frame with three variables: \code{r}, \code{t},
#'   \code{nms}.
"mic"

#' Hobbs data
#'
#' Description TBD.
#'
#' @format A data frame with three variables: \code{r}, \code{t},
#'   \code{nms}.
"hobbs"
